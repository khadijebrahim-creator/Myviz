import matplotlib.pyplot as plt

def apply_style():
    plt.rcParams.update({
        "figure.figsize": (8, 5),
        "axes.titlesize": 14,
        "axes.labelsize": 12,
        "lines.linewidth": 2,
    })
