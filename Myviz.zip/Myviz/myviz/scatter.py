import matplotlib.pyplot as plt
from .style import apply_style

def styled_scatter(x, y, title="", color="tab:red"):
    apply_style()
    plt.scatter(x, y, color=color)
    plt.title(title)
    plt.show()
