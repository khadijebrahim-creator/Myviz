from .line import styled_line
from .bar import styled_bar
from .scatter import styled_scatter
from .hist import styled_hist
from .box import styled_box
